# mACHINE LEARNING SETUP FILE
from setuptools import setup, find_packages
import codecs
import os

VERSION = '1.0.2.1'
DESCRIPTION = 'Machine Learning models make simple'
LONG_DESCRIPTION = '''

                                        Machine Learning models
                                    (single-file, easy-to-use, and modular)

                classfication model
                        classifier->
                                Scaling->
                                    standard_scaler    
                                    MinMax
                                TrainSplitTest->
                                            split
                                classifierSingleModel->
                                                    model_fit
                                classifierHyper->
                                            adaBoost, ada_pred 
                                            randomforest, rf_pred 
                                            gradientboost, gb_pred
                                            logistic, l_pred 
                                            svm, svm_pred 
                                            knn, knn_pred 
                                            binomialnb, nb_pred 
                                            multinomialnb, multinomialnb_pred 
                                            gaussiannb, gaussiannb_pred 
                                            decisiontree, decisiontree_pred 
                                            xgboost, xgboost_pred 
                                            bagging, bagging_pred 
                                            extra, extra_pred 
                                            ridge, ridge_pred
                                    
                                Modelling->
                                        logistic, log_pred
                                        k_nn, knn_pred 
                                        svc, svc_pred 
                                        decision_tree, dt_pred 
                                        random_forest, rf_pred 
                                        gradient_boosting, gb_pred 
                                        XGBOOST, xgb_pred 
                                        adaBoostC, abc_pred 
                                        bernoullinb, bnb_pred 
                                        multinomialnb, mnb_pred 
                                        bagging, bagging_pred 
                                        extraTrees, et_pred 
                                        ridge, r_pred 
                                        sgd, sgd_pred
                                                        
'''

# Setting up
setup(
    name="ml-pkg-models",
    version=VERSION,
    author="sajo sam",
    author_email="<sajosamambalakara@gmail.com>",
    description=DESCRIPTION,
    long_description_content_type="text/markdown",
    long_description=LONG_DESCRIPTION,
    packages=find_packages(),
    install_requires=['pandas'],
    keywords=['python', 'classification','regression','machine learning models','hyper parameter turning'],
    classifiers=[
        "Development Status :: 1 - Planning",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Operating System :: Unix",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: Microsoft :: Windows",
    ]
)

